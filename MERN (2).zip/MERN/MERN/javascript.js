// setTimeout(() => {
//     console.log("Done")
// }, 4000);

// const pr = new Promise((res,rej)=>{
//     let flag = true;
//     if(flag ===true){
//         setTimeout(() => {
//             res(["apple"])
//         }, 4000);
//     }
// })

// pr.then((val)=>{
//     console.log(val)
// })

// let count =0
// let id;

// const cb = () =>{
//     count++;
//     console.log("Done", count);
//     if(count==4){
//         clearInterval(id);
//     }
// }
// const time = 1000

// id=setInterval(cb,time)

const fruits = ['Banana','Apple', "Orange"]
console.log(fruits[0])

